import os
import random
from datetime import datetime, timezone
from azure.cosmos import CosmosClient, exceptions

# ============================================================
# RATIOS
# ============================================================
GOOD_RATIO = 0.65
BAD_CONTEXT_RATIO = 0.20
BAD_ANSWER_RATIO = 0.15

# ============================================================
# USERS / TRACE TYPES
# ============================================================
USERS = [f"user-{str(i).zfill(4)}" for i in range(1, 501)]

TRACE_NAMES = [
    "simple-qa",
    "multi-hop-reasoning",
    "tool-use-flow"
]

# ============================================================
# EXPANDED SMART-FACTORY DATASET
# ============================================================
DATA = [
    {
        "input": "Explain valve shutdown procedure",
        "context": (
            "Standard valve shutdown includes isolating flow from both ends and slowly relieving "
            "pressure. Some legacy diagrams mention manual bleed-off valves which may not exist "
            "in newer installations, so operators must verify on-site. Incorrect sequencing can "
            "lead to sudden pressure differentials."
        ),
        "output": (
            "Shutdown involves isolation, pressure relief, and ensuring the valve reaches a confirmed "
            "zero-energy state. Some systems may require manual bleed steps."
        )
    },
    {
        "input": "Why does the circuit breaker trip repeatedly?",
        "context": (
            "Breaker tripping patterns can indicate overload or a failing thermal element. In some "
            "rare cases, control panel humidity causes condensation leading to intermittent shorts. "
            "Technicians should compare load profiles with historical baselines."
        ),
        "output": (
            "Breakers may trip from overloads, thermal wear, or moisture-related faults. Load "
            "comparison with past baselines helps confirm the issue."
        )
    },
    {
        "input": "What caused the temperature spike in the reactor?",
        "context": (
            "Reactor temperature spikes often originate from cooling-loop imbalance or sensor drift. "
            "However, uncalibrated flow meters can falsely report flow status, masking partial blockages. "
            "Operators should validate readings using redundant meters."
        ),
        "output": (
            "Temperature spikes typically indicate cooling-loop issues, but faulty flow sensors can also "
            "cause misleading readings."
        )
    },
    {
        "input": "How do you stabilize steam pipeline pressure?",
        "context": (
            "Pressure stabilization depends on inlet-feed variability. In older facilities, steam traps "
            "clog frequently due to mineral deposits, creating inconsistent downstream pressure. "
            "Gradual valve modulation is recommended to avoid hammering."
        ),
        "output": (
            "Stabilization is achieved via controlled valve modulation and verifying steam trap "
            "performance."
        )
    },
    {
        "input": "Why did the robotic arm freeze during operation?",
        "context": (
            "Robotic stalls may occur from encoder desync, lubrication issues, or PLC communication jitter. "
            "In rare cases, electromagnetic interference from nearby welders disrupts encoder pulses."
        ),
        "output": (
            "Freezing occurs due to encoder desync or PLC communication delays, sometimes EMI-induced."
        )
    },
    {
        "input": "How do you detect compressed air leakage?",
        "context": (
            "Leak detection typically uses ultrasonic sensors. Some modern systems use pressure-decay "
            "profiling with AI-based anomaly detection. Environmental noise can reduce sensor accuracy."
        ),
        "output": (
            "Leaks are detected using ultrasonic scanning or pressure decay methods, depending on system type."
        )
    },
    {
        "input": "Why is the conveyor belt misaligned?",
        "context": (
            "Misalignment often results from uneven load, worn idlers, warped frames, or temperature-induced "
            "belt expansion. Some belts drift only under higher humidity conditions due to material swelling."
        ),
        "output": (
            "Causes include uneven load, worn idlers, or environmental expansion of belt material."
        )
    },
    {
        "input": "What causes abnormal vibration in motors?",
        "context": (
            "Abnormal vibration can arise from shaft imbalance, incorrect mounting torque, bearing wear, or "
            "electrical issues like air-gap irregularity. Vibration signatures often reveal harmonic patterns."
        ),
        "output": (
            "Vibration occurs due to imbalance, worn bearings, or torque/mounting issues."
        )
    },
    {
        "input": "How do you handle hydraulic pressure loss?",
        "context": (
            "Pressure loss sources include micro-leaks in seals, cavitation inside pumps, or partially clogged "
            "return lines. Pressure gauges older than 2 years may show drift, causing false interpretations."
        ),
        "output": (
            "Loss is handled by checking seals, pump cavitation, clogged return lines, and gauge accuracy."
        )
    },
    {
        "input": "Why did the PLC stop responding?",
        "context": (
            "PLC lock-up may stem from I/O bus saturation, firmware corruption, aged capacitors in power "
            "supplies, or noisy grounding. Some older PLCs fail after warm-up due to thermal derating."
        ),
        "output": (
            "PLC stops due to I/O saturation, firmware faults, grounding noise, or thermal derating."
        )
    }
]


BAD_ANSWERS = [
    "This issue is caused by gravitational anomalies in the facility.",
    "The machine stopped because it was tired after long usage.",
    "Cosmic radiation interfered with the control system.",
    "The reactor overheated due to internet connectivity issues.",
    "A software bug in the login system caused the pressure spike."
]

ALL_CONTEXTS = [d["context"] for d in DATA]

# ============================================================
# TRACE COUNTER
# ============================================================
def get_next_trace_number(counter_container):
    try:
        doc = counter_container.read_item(
            item="trace_counter",
            partition_key="trace_counter"
        )
        next_no = doc["value"] + 1
    except exceptions.CosmosResourceNotFoundError:
        next_no = 1
        doc = {
            "id": "trace_counter",
            "partitionKey": "trace_counter",
            "value": 0
        }

    doc["value"] = next_no
    counter_container.upsert_item(doc)
    return next_no

# ============================================================
# TRACE BUILDER
# ============================================================
def make_trace(trace_no, session_id, user_id, trace_name, input_text, context_text, output_text):

    tokens_in = random.randint(200, 3500)
    tokens_out = random.randint(50, 1500)

    trace_id = f"trace-{str(trace_no).zfill(4)}"

    return {
        "id": trace_id,
        "partitionKey": trace_id,      # 🔥 PK = trace_id
        "trace_id": trace_id,

        "session_id": session_id,
        "user_id": user_id,
        "trace_name": trace_name,
        "timestamp": datetime.now(timezone.utc).isoformat(),

        "input": input_text,
        "output": output_text,

        "latency_ms": random.randint(200, 8000),
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "tokens": tokens_in + tokens_out,
        "cost": round((tokens_in + tokens_out) * random.uniform(0.00008, 0.00025), 5),

        "model": random.choice(["gpt-4o", "gpt-4o-mini", "llama-3.3-70b"]),
    }

# ============================================================
# TIMER FUNCTION
# ============================================================
def main(mytimer):

    cosmos = CosmosClient.from_connection_string(
        os.environ["COSMOS_CONN_WRITE"]
    )
    db = cosmos.get_database_client("llmops-data")

    traces_container = db.get_container_client("traces")
    counter_container = db.get_container_client("metrics")

    # 🔥 HIGH VOLUME GENERATION
    for _ in range(random.randint(2, 5)):
        base = random.choice(DATA)

        input_text = base["input"]
        context_text = base["context"]
        output_text = base["output"]

        r = random.random()
        if GOOD_RATIO <= r < GOOD_RATIO + BAD_CONTEXT_RATIO:
            context_text = random.choice([c for c in ALL_CONTEXTS if c != context_text])
        elif r >= GOOD_RATIO + BAD_CONTEXT_RATIO:
            output_text = random.choice(BAD_ANSWERS)

        trace_no = get_next_trace_number(counter_container)

        trace = make_trace(
            trace_no=trace_no,
            session_id=f"session-{random.randint(1, 200)}",
            user_id=random.choice(USERS),
            trace_name=random.choice(TRACE_NAMES),
            input_text=input_text,
            context_text=context_text,
            output_text=output_text
        )

        # ✅ MUST use create_item for Cosmos trigger
        traces_container.create_item(trace)
